<?php
session_start();
echo isset($_SESSION['username']) ? '1' : '0';
?>